
package clase.pkg1;

import java.util.Scanner;
//metodo

public class Clase1 {
    //divisor
    public static boolean divisor(int a, int b){
        return b%a == 0;
    }
    //suma de los divisores
    public static int suma (int w){
      int sum = 1;
      for (int i = 2; i<w; i++)
          if (divisor(i,w)){//esto se usa en vez de poner con porcentaje
              sum+= i;
          }
          return sum;
    }
    //resultado
    public static boolean amigos (int x, int y){
    return suma(x)== y && suma(y)== x;//suma de los divisores propios
}
    //Números amigos
    public static void main(String[] args) {
        Scanner dato = new Scanner(System.in);
        //Declaración de variables
        int num1,num2;
        System.out.println("Ingrese dos números enteros");
        //Leer los dos numeros
        num1 = dato.nextInt();
        num2 = dato.nextInt();
        //Proceso
        if(amigos(num1,num2)){
            System.out.println(num1+" y "+num2+" son numeros amigos ");
        }
        else{
           System.out.println(num1+" y "+num2+" no son numeros amigos ");
        }
    }
    
}
